0.1.18
  - Fix bugs on MacOS
