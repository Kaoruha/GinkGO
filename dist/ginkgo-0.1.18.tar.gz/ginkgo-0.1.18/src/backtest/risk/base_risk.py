"""
风控类
"""


class BaseRisk(object):
    """
    风控基类
    回头改成抽象类
    """
    pass