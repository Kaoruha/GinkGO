import unittest
from src.backtest.broker.base_broker import BaseBroker
from src.backtest.event_engine import EventEngine
from src.backtest.strategy.base_strategy import BaseStrategy
from src.backtest.sizer.base_sizer import BaseSizer
from src.backtest.risk.base_risk import BaseRisk
from src.backtest.matcher.base_matcher import BaseMatcher
from src.backtest.analyzer.base_analyzer import BaseAnalyzer
from src.backtest.painter.base_painter import BasePainter


# 必传项测试
# 唯一字段值测试
# 空值测试
# 字段只接受允许的字符
# 负值测试
# 字段限于字段长度规范
# 不可能的值
# 垃圾值测试
# 检查字段之间的依赖性
# 等效类划分和边界条件测试
# 错误和异常处理测试


class BrokerTest(unittest.TestCase):
    """
    经纪人类单元测试
    """

    def __init__(self, *args, **kwargs):
        super(BrokerTest, self).__init__(*args, **kwargs)
        self.base_broker = BaseBroker(name="base", engine=EventEngine(), init_capital=10000)

    # def test_init_OK(self):
    #     """
    #     经纪人类初始化
    #     """
    #     test_tuple = [
    #         (1000), (0), (10000)
    #     ]
    #     for i in test_tuple:
    #         b = BaseBroker(name='test_broker', engine=EventEngine(), init_capital=i[0])
    #         self.assertEqual(
    #             first={
    #                 "name": "test_broker",
    #                 "init_capital": i[0],
    #             },
    #             second={
    #                 "name": b.name,
    #                 "init_capital": b.init_capital,
    #             }
    #         )
    #     return b
    #
    # def test_getcash_OK(self):
    #     """
    #     经纪人实例入金
    #     """
    #     b = self.test_init_OK()
    #     b.get_cash(10000)
    #     self.assertEqual(
    #         first={
    #             "name": "test_broker",
    #             "init_capital": 110000,
    #             "capital": 110000
    #         },
    #         second={
    #             "name": b.name,
    #             "init_capital": b.init_capital,
    #             "capital": b.capital
    #         }
    #     )
    #
    # def test_registernostrategy_FAILED(self):
    #     """
    #     注册一个非策略实例
    #     """
    #     b = self.test_init_OK()
    #     s2 = 1
    #     b.strategy_register(s2)
    #     self.assertEqual(
    #         first={
    #             "strategy_count": 0,
    #         },
    #         second={
    #             "strategy_count": len(b.strategies),
    #         }
    #     )
    #
    # def test_registerstrategy_OK(self):
    #     """
    #     注册一个策略实例
    #     """
    #     b = self.test_init()
    #     s = BaseStrategy(name="test_s")
    #     b.strategy_register(s)
    #     self.assertEqual(
    #         first={
    #             "strategy_count": 1,
    #             'strategy_name': 'test_s'
    #         },
    #         second={
    #             "strategy_count": len(b.strategies),
    #             'strategy_name': b.strategies[0].name
    #         }
    #     )
    #
    # def test_register_same_strategy_times(self):
    #     """
    #     重复注册一个策略实例
    #     """
    #     b = self.test_init()
    #     s = BaseStrategy(name="test_s")
    #     b.strategy_register(s)
    #     b.strategy_register(s)
    #     self.assertEqual(
    #         first={
    #             "strategy_count": 1,
    #             'strategy_name': 'test_s'
    #         },
    #         second={
    #             "strategy_count": len(b.strategies),
    #             'strategy_name': b.strategies[0].name
    #         }
    #     )
    #
    # def test_register_strategy_with_same_name_twice(self):
    #     """
    #     注册多个同名策略实例
    #     """
    #     b = self.test_init()
    #     s = BaseStrategy(name="test_s")
    #     s2 = BaseStrategy(name="test_s")
    #     b.strategy_register(s)
    #     b.strategy_register(s2)
    #     self.assertEqual(
    #         first={
    #             "strategy_count": 2,
    #             'strategy_name': 'test_s'
    #         },
    #         second={
    #             "strategy_count": len(b.strategies),
    #             'strategy_name': b.strategies[0].name
    #         }
    #     )
    #
    # def test_register_not_sizer(self):
    #     """
    #     注册非仓位控制实例
    #     """
    #     b = self.test_init()
    #     s = 'str'
    #     b.sizer_register(s)
    #     self.assertEqual(
    #         first={
    #             "sizer": None,
    #         },
    #         second={
    #             "sizer": b.sizer,
    #         }
    #     )
    #
    # def test_register_sizer(self):
    #     """
    #     注册仓位控制实例
    #     """
    #     b = self.test_init()
    #     s = BaseSizer(name='test_sizer')
    #     b.sizer_register(s)
    #     self.assertEqual(
    #         first={
    #             "sizer": s,
    #             'name': 'test_sizer'
    #         },
    #         second={
    #             "sizer": b.sizer,
    #             'name': b.sizer.name
    #         }
    #     )
    #
    # def test_register_sizer_twice(self):
    #     """
    #     重复注册仓位控制实例
    #     """
    #     b = self.test_init()
    #     s = BaseSizer(name='test_sizer')
    #     b.sizer_register(s)
    #     b.sizer_register(s)
    #     self.assertEqual(
    #         first={
    #             "sizer": s,
    #             'name': 'test_sizer'
    #         },
    #         second={
    #             "sizer": b.sizer,
    #             'name': b.sizer.name
    #         }
    #     )
    #
    # def test_register_sizer_then_nosizer(self):
    #     """
    #     先注册仓位控制实例，后注册非仓位控制实例
    #     """
    #     b = self.test_init()
    #     s = BaseSizer(name='test_sizer')
    #     b.sizer_register(s)
    #     b.sizer_register(11)
    #     self.assertEqual(
    #         first={
    #             "sizer": s,
    #             'name': 'test_sizer'
    #         },
    #         second={
    #             "sizer": b.sizer,
    #             'name': b.sizer.name
    #         }
    #     )
    #
    # def test_register_sizer4(self):
    #     """
    #     先注册非仓位控制实例，后注册仓位控制实例
    #     """
    #     b = self.test_init()
    #     s = BaseSizer(name='test_sizer')
    #     b.sizer_register(11)
    #     b.sizer_register(s)
    #     self.assertEqual(
    #         first={
    #             "sizer": s,
    #             'name': 'test_sizer'
    #         },
    #         second={
    #             "sizer": b.sizer,
    #             'name': b.sizer.name
    #         }
    #     )
