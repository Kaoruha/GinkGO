import unittest
from src.backtest.postion import Position


class PositionTest(unittest.TestCase):
    """
    持仓类单元测试
    """
    def test_init(self):
        """
        持仓类初始化
        """
        p = Position(code="test_code", price=1.0, volume=100, date="2020-01-01")
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 100,
                "date": "2020-01-01",
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
            }
        )

    def test_buy0(self):
        """
        持仓类买入0手
        """
        p = Position(code="test_code", price=1.0, volume=100, date="2020-01-01")
        p.buy(price=2, volume=0)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 100,
                "date": "2020-01-01",
                "freeze":0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_buy1(self):
        """
        持仓类买入正常
        """
        p = Position(code="test_code", price=1.0, volume=100, date="2020-01-01")
        p.buy(price=2, volume=200)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": round((100+400)/300,2),
                "volume": 300,
                "date": "2020-01-01",
                'freeze':0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_presell0(self):
        """
        持仓类预卖出0手
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(0)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 4000,
                "date": "2020-01-01",
                'freeze':0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_presell1(self):
        """
        持仓类预卖出正常
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(2000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 2000,
                "date": "2020-01-01",
                'freeze':2000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
    
    def test_presell2(self):
        """
        持仓类预卖出所有
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
    
    def test_presell3(self):
        """
        持仓类预卖出超持有
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(5000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell0(self):
        """
        持仓类成功卖出0
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(0,True)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell2(self):
        """
        持仓类成功卖出正常量
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(2000,True)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':2000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell3(self):
        """
        持仓类成功全部
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(0,True)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell4(self):
        """
        持仓类成功卖出量超持有量
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(5000,True)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell_failed0(self):
        """
        持仓类失败卖出0
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(0,False)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell_failed1(self):
        """
        持仓类失败卖出正常
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(1000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 3000,
                "date": "2020-01-01",
                'freeze':1000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(2000,False)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 4000,
                "date": "2020-01-01",
                'freeze':0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )

    def test_sell_failed2(self):
        """
        持仓类失败卖出超持有量
        """
        p = Position(code="test_code", price=1.0, volume=4000, date="2020-01-01")
        p.per_sell(4000)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 0,
                "date": "2020-01-01",
                'freeze':4000
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )
        p.sell(5000,False)
        self.assertEqual(
            first={
                "code": "test_code",
                "price": 1,
                "volume": 4000,
                "date": "2020-01-01",
                'freeze':0
            },
            second={
                "code": p.code,
                "price": p.price,
                "volume": p.volume,
                "date": p.date,
                'freeze':p.freeze
            },
        )