import logging

# 开发/生产环境下相同的配置
DEBUG = True
TOKEN_EXPIRATION = 14  # Token过期时间（天）

LOGGING_LEVEL = logging.DEBUG
