"""
数据存储模块，负责与Clickhouse通信
"""